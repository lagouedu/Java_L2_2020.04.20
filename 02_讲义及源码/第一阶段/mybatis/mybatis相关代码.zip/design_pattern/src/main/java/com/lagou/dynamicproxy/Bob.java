package com.lagou.dynamicproxy;

public class Bob implements Person {

    @Override
    public void doSomething() {
        System.out.println("Bob doing Something");
    }
}
