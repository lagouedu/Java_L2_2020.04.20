package com.lagou.dynamicproxy;

public interface Person {
    public void doSomething();

}
