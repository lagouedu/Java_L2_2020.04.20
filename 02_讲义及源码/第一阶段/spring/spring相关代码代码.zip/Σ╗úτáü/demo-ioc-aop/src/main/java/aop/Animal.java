package aop;

import javax.swing.plaf.synth.SynthStyle;

/**
 * @author 应癫
 */
public class Animal {

    private String height; // 高度
    private float weight;  // 体重

    public void eat(){



        // 业务逻辑代码
        System.out.println("I can eat...");


    }

    public void run(){


        // 业务逻辑代码
        System.out.println("I can run...");

    }

}
