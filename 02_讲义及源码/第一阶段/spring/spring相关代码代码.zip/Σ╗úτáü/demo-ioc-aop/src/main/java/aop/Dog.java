package aop;

/**
 * @author 应癫
 */
public class Dog extends Animal{

    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.eat();
        dog.run();
    }
}
