package com.lagou.springboot05_cache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot05CacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
