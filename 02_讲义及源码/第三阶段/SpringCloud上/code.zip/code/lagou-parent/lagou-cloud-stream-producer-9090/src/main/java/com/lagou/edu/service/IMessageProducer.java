package com.lagou.edu.service;

public interface IMessageProducer {


    public void sendMessage(String content);
}
