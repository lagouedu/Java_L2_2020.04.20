package com.lagou.service;

public interface IUserService {

    public String sayHello(String smg);

}
