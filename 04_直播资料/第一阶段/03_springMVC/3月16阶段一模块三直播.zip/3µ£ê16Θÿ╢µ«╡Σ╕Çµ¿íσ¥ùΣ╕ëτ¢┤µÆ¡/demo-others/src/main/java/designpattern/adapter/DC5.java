package designpattern.adapter;

public interface DC5 {

    int outputDC5V();
}